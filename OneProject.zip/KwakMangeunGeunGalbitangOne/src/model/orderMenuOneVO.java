package model;

public class orderMenuOneVO {
	private int no;
	private String manuname;
	private String orderdate;
	private String payment;
	private int price;

	public orderMenuOneVO() {
		super();
	}

	public orderMenuOneVO(String manuname, String orderdate, String payment, int price) {
		super();
		this.manuname = manuname;
		this.orderdate = orderdate;
		this.payment = payment;
		this.price = price;
	}

	public orderMenuOneVO(int no, String manuname, String orderdate, String payment, int price) {
		super();
		this.no = no;
		this.manuname = manuname;
		this.orderdate = orderdate;
		this.payment = payment;
		this.price = price;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getManuname() {
		return manuname;
	}

	public void setManuname(String manuname) {
		this.manuname = manuname;
	}

	public String getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}