package Control;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.orderMenuOneVO;

public class orderMenuOneDAO {
	// ���
	public orderMenuOneVO getordateregiste(orderMenuOneVO ovo) throws Exception {
		//sql �Է���  ������  ��������
		String sql = "insert into ordertabel " + "(no, manuname, orderdate, payment, price)" + "values "
				+ "(ordertable_sql.nextval,?,?,?,?)";

		Connection con = null;
		PreparedStatement pstmt = null;
		orderMenuOneVO oVo = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, ovo.getManuname());
			pstmt.setString(2, ovo.getOrderdate());
			pstmt.setString(3, ovo.getPayment());
			pstmt.setInt(4, ovo.getPrice());

			int i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println("��� �ַ� DAO =[" + e + "]");
		} catch (Exception e) {
			System.out.println("e=[" + e + "]");
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return oVo;
	}

	public ArrayList<orderMenuOneVO> getorderMenuOneTotal() {
		ArrayList<orderMenuOneVO> list = new ArrayList<orderMenuOneVO>();
		String tml = "select * from ordertabel";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		orderMenuOneVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				emVo = new orderMenuOneVO(rs.getInt(1), rs.getString(2), rs.getDate(3)+"", rs.getString(4),
						rs.getInt(5));
				list.add(emVo);
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return list;
	}

	// �����ͺ��̽����� �л� ���̺� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from  ordertabel";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; // ��ü�������� resultset�ǳ�������
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return columnName;
	}

	// ��������
	public void getbtnDelete(int no) throws Exception {
		String dml = "delete from ordertabel where no =?";
		Connection con = null;
		PreparedStatement pstmt = null;
		System.out.println(no + "���� ");
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, no);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�����Է�");
				alert.setHeaderText("�޴���� ���� ���� ");
				
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
				con.close();
			} catch (SQLException se) {

			}
		}
	}
	//��ü ����
	public void getbtnAllDelete() throws Exception {
		String dml = "delete from ordertabel "; //sql ���� ���� 
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�����Է�");
				alert.setHeaderText("�޴���� ���� ���� ");
				
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);

		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
				con.close();
			} catch (SQLException se) {

			}
		}
	}
}
